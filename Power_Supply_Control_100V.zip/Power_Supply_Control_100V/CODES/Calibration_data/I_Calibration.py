# -*- coding: utf-8 -*-
"""
Created on Tue Jun 15 11:57:09 2021
This program is used to plot the DAC2Voltage Calibration data
"""
import numpy as np
import matplotlib.pyplot as plt
import LT.box as B

d = np.loadtxt('C:/Users/plasma/Desktop/Power_Supply_Control_50V/Calibration_data/Ch8_ADC_Current.txt')
#d = np.loadtxt('C:/Users/plasma/Desktop/Power_Supply_Control_50V/Calibration_data/CH8ADC2Voltage.txt')

#DAC  = d[:,0]
ADC  = d[:,0]
I1   = d[:,1]


#Plotting the Voltage Calibration data:
plt.figure(1)
plt.plot(ADC, I1, label='I4', marker = 'o')
plt.xlabel('ADC Analog Number')
plt.ylabel('Current')
plt.legend()

p = B.polyfit(ADC, I1, order =1)
B.plot_exp(ADC, I1)
B.plot_line(p.xpl, p.ypl)
plt.xlabel('ADC Analog Number')
plt.ylabel('Current (nA)')
plt.legend()


"""
def current(x):
    return -6.988264608053669 +1.000699589309391 *x 
"""

plt.show()