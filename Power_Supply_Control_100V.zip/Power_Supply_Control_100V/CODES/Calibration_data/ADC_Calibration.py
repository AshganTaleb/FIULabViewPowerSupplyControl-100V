# -*- coding: utf-8 -*-
"""
Created on Tue Jun 15 11:57:09 2021
This program is used to plot the DAC2Voltage Calibration data
"""
import numpy as np
import matplotlib.pyplot as plt

d = np.loadtxt('C:/Users/plasma/Desktop/Power_Supply_Control_100V/Calibration_data/DAC2ADC_Calibration.txt')


DAC = d[:,0]
ADC1  = d[:,1]
ADC2  = d[:,2]
ADC3  = d[:,3]
ADC4  = d[:,4]
ADC5  = d[:,5]
ADC6  = d[:,6]
ADC7  = d[:,7]
ADC8  = d[:,8]

#Plotting the Voltage Calibration data:
plt.figure(1)
plt.plot(DAC, ADC1, label='Ch1')
plt.plot(DAC, ADC2, label='Ch2')
plt.plot(DAC, ADC3, label='Ch3')
plt.plot(DAC, ADC4, label='Ch4')
plt.plot(DAC, ADC5, label='Ch5')
plt.plot(DAC, ADC6, label='Ch6')
plt.plot(DAC, ADC7, label='Ch7')
plt.plot(DAC, ADC8, label='Ch8')

plt.xlabel(' Digital to Analog Number (DAC)')
plt.ylabel(' Analog to Digital Number (ADC')
plt.legend()





plt.show()